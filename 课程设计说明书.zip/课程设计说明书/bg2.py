import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from PIL import Image, ImageTk
import random


class RestaurantOrderingSystem:
    def __init__(self, root):
        self.root = root
        self.root.title("美味餐厅点菜系统")
        self.root.geometry("900x650")
        self.root.resizable(False, False)
        self.root.configure(bg="#f0f8ff")

        # 创建菜单数据
        self.menu_items = {
            "宫保鸡丁": 48,
            "鱼香肉丝": 42,
            "水煮鱼": 68,
            "麻婆豆腐": 38,
            "回锅肉": 52,
            "糖醋里脊": 55,
            "清蒸鲈鱼": 78,
            "红烧狮子头": 65,
            "葱爆羊肉": 62,
            "干煸豆角": 36,
            "蒜蓉西兰花": 32,
            "酸辣土豆丝": 28,
            "西红柿炒鸡蛋": 30,
            "白灼生菜": 26,
            "扬州炒饭": 35,
            "海鲜炒面": 45,
            "三鲜水饺": 38,
            "小笼包": 32,
            "银耳羹": 28,
            "水果拼盘": 48
        }

        # 当前订单
        self.order = {}

        # 创建UI
        self.create_widgets()

    def create_widgets(self):
        # 标题
        title_frame = tk.Frame(self.root, bg="#ff6b6b", height=80)
        title_frame.pack(fill="x", padx=10, pady=10)

        title_label = tk.Label(title_frame, text="美味餐厅点菜系统", font=("微软雅黑", 24, "bold"),
                               fg="white", bg="#ff6b6b")
        title_label.pack(pady=20)

        # 主内容区
        main_frame = tk.Frame(self.root, bg="#f0f8ff")
        main_frame.pack(fill="both", expand=True, padx=20, pady=10)

        # 菜单区
        menu_frame = tk.LabelFrame(main_frame, text="菜单", font=("微软雅黑", 12),
                                   bg="#e3f2fd", padx=10, pady=10)
        menu_frame.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")

        # 菜单表格
        columns = ("菜品", "价格")
        self.menu_table = ttk.Treeview(menu_frame, columns=columns, show="headings", height=10)

        # 设置列
        self.menu_table.column("菜品", width=200, anchor="w")
        self.menu_table.column("价格", width=100, anchor="center")

        # 设置表头
        self.menu_table.heading("菜品", text="菜品")
        self.menu_table.heading("价格", text="价格(元)")

        # 添加滚动条
        scrollbar = ttk.Scrollbar(menu_frame, orient="vertical", command=self.menu_table.yview)
        self.menu_table.configure(yscrollcommand=scrollbar.set)

        # 添加数据
        for item, price in self.menu_items.items():
            self.menu_table.insert("", "end", values=(item, price))

        self.menu_table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 点菜区
        order_frame = tk.LabelFrame(main_frame, text="点菜", font=("微软雅黑", 12),
                                    bg="#e3f2fd", padx=10, pady=10)
        order_frame.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")

        # 菜品选择
        tk.Label(order_frame, text="选择菜品:", bg="#e3f2fd", font=("微软雅黑", 10)).pack(anchor="w", pady=(5, 0))
        self.selected_dish = tk.StringVar()
        dish_combo = ttk.Combobox(order_frame, textvariable=self.selected_dish,
                                  values=list(self.menu_items.keys()), width=20)
        dish_combo.pack(fill="x", pady=5)
        dish_combo.current(0)

        # 数量选择
        tk.Label(order_frame, text="数量:", bg="#e3f2fd", font=("微软雅黑", 10)).pack(anchor="w", pady=(10, 0))
        self.quantity = tk.IntVar(value=1)
        ttk.Spinbox(order_frame, from_=1, to=10, textvariable=self.quantity, width=5).pack(anchor="w", pady=5)

        # 添加按钮
        add_btn = tk.Button(order_frame, text="添加到订单", command=self.add_to_order,
                            bg="#4caf50", fg="white", font=("微软雅黑", 10), padx=10)
        add_btn.pack(pady=15)

        # 折扣输入
        tk.Label(order_frame, text="折扣率 (0-1):", bg="#e3f2fd", font=("微软雅黑", 10)).pack(anchor="w", pady=(10, 0))
        self.discount = tk.DoubleVar(value=0.9)
        discount_entry = tk.Entry(order_frame, textvariable=self.discount, width=8)
        discount_entry.pack(anchor="w", pady=5)

        # 订单区
        order_display_frame = tk.LabelFrame(main_frame, text="当前订单", font=("微软雅黑", 12),
                                            bg="#e3f2fd", padx=10, pady=10)
        order_display_frame.grid(row=1, column=0, columnspan=2, padx=10, pady=10, sticky="nsew")

        # 订单表格
        columns = ("菜品", "单价", "数量", "小计")
        self.order_table = ttk.Treeview(order_display_frame, columns=columns, show="headings", height=5)

        # 设置列
        self.order_table.column("菜品", width=200, anchor="w")
        self.order_table.column("单价", width=100, anchor="center")
        self.order_table.column("数量", width=100, anchor="center")
        self.order_table.column("小计", width=100, anchor="center")

        # 设置表头
        self.order_table.heading("菜品", text="菜品")
        self.order_table.heading("单价", text="单价(元)")
        self.order_table.heading("数量", text="数量")
        self.order_table.heading("小计", text="小计(元)")

        # 添加滚动条
        scrollbar = ttk.Scrollbar(order_display_frame, orient="vertical", command=self.order_table.yview)
        self.order_table.configure(yscrollcommand=scrollbar.set)

        self.order_table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # 订单统计
        stats_frame = tk.Frame(order_display_frame, bg="#e3f2fd")
        stats_frame.pack(side="right", fill="y", padx=(10, 0))

        self.total_label = tk.Label(stats_frame, text="总价: 0.00元", font=("微软雅黑", 11), bg="#e3f2fd")
        self.total_label.pack(pady=5, anchor="e")

        self.discount_label = tk.Label(stats_frame, text="折扣率: 0.9", font=("微软雅黑", 11), bg="#e3f2fd")
        self.discount_label.pack(pady=5, anchor="e")

        self.final_label = tk.Label(stats_frame, text="实付金额: 0.00元", font=("微软雅黑", 11, "bold"),
                                    bg="#e3f2fd", fg="#d32f2f")
        self.final_label.pack(pady=5, anchor="e")

        # 操作按钮
        button_frame = tk.Frame(main_frame, bg="#f0f8ff")
        button_frame.grid(row=2, column=0, columnspan=2, pady=10)

        tk.Button(button_frame, text="计算总价", command=self.calculate_total,
                  bg="#2196f3", fg="white", font=("微软雅黑", 11), padx=15).pack(side="left", padx=10)

        tk.Button(button_frame, text="清空订单", command=self.clear_order,
                  bg="#f44336", fg="white", font=("微软雅黑", 11), padx=15).pack(side="left", padx=10)

        tk.Button(button_frame, text="完成订单", command=self.complete_order,
                  bg="#4caf50", fg="white", font=("微软雅黑", 11), padx=15).pack(side="left", padx=10)

        # 状态栏
        status_frame = tk.Frame(self.root, bg="#e0e0e0", height=30)
        status_frame.pack(fill="x", padx=10, pady=(0, 10))

        self.status_label = tk.Label(status_frame, text="就绪", bg="#e0e0e0", font=("微软雅黑", 9))
        self.status_label.pack(side="left", padx=10)

        # 设置网格配置
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(0, weight=1)
        main_frame.rowconfigure(1, weight=1)

    def add_to_order(self):
        dish = self.selected_dish.get()
        quantity = self.quantity.get()

        if not dish:
            messagebox.showwarning("警告", "请选择菜品！")
            return

        price = self.menu_items[dish]
        subtotal = price * quantity

        # 如果菜品已经在订单中，更新数量
        if dish in self.order:
            self.order[dish]["quantity"] += quantity
            self.order[dish]["subtotal"] += subtotal
        else:
            self.order[dish] = {
                "price": price,
                "quantity": quantity,
                "subtotal": subtotal
            }

        # 更新订单表格
        self.update_order_table()
        self.status_label.config(text=f"已添加 {quantity}份 {dish}")

    def update_order_table(self):
        # 清空表格
        for item in self.order_table.get_children():
            self.order_table.delete(item)

        # 添加当前订单
        for dish, details in self.order.items():
            self.order_table.insert("", "end", values=(
                dish,
                details["price"],
                details["quantity"],
                details["subtotal"]
            ))

        # 计算总价
        self.calculate_total()

    def calculate_total(self):
        total = sum(details["subtotal"] for details in self.order.values())

        try:
            discount = float(self.discount.get())
            if discount < 0 or discount > 1:
                raise ValueError()
        except:
            discount = 1.0
            self.discount.set(1.0)
            messagebox.showerror("错误", "折扣率必须在0到1之间！")

        final_total = total * discount

        self.total_label.config(text=f"总价: {total:.2f}元")
        self.discount_label.config(text=f"折扣率: {discount:.2f}")
        self.final_label.config(text=f"实付金额: {final_total:.2f}元")

    def clear_order(self):
        self.order = {}
        self.update_order_table()
        self.status_label.config(text="订单已清空")

    def complete_order(self):
        if not self.order:
            messagebox.showwarning("警告", "订单为空，无法完成订单！")
            return

        self.calculate_total()
        total = sum(details["subtotal"] for details in self.order.values())
        discount = float(self.discount.get())
        final_total = total * discount

        # 生成订单详情
        order_details = "=== 美味餐厅订单 ===\n\n"
        for dish, details in self.order.items():
            order_details += f"{dish} x{details['quantity']} : {details['subtotal']:.2f}元\n"

        order_details += f"\n总价: {total:.2f}元\n"
        order_details += f"折扣率: {discount:.2f}\n"
        order_details += f"实付金额: {final_total:.2f}元\n\n"
        order_details += "感谢惠顾，欢迎下次光临！"

        # 显示订单完成信息
        messagebox.showinfo("订单完成", order_details)

        # 清空订单
        self.clear_order()
        self.status_label.config(text="订单已完成，感谢惠顾！")


# 运行程序
if __name__ == "__main__":
    root = tk.Tk()
    app = RestaurantOrderingSystem(root)
    root.mainloop()


