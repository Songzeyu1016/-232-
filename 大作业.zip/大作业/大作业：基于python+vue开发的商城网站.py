# Python + Vue 网上商城系统设计与实现
from flask import Flask, jsonify, request, render_template_string
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'


# 初始化数据库
def init_db():
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()

    # 创建用户表
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 username TEXT UNIQUE NOT NULL,
                 password TEXT NOT NULL,
                 email TEXT NOT NULL,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # 创建商品表
    c.execute('''CREATE TABLE IF NOT EXISTS products
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT NOT NULL,
                 description TEXT,
                 price REAL NOT NULL,
                 stock INTEGER NOT NULL,
                 category_id INTEGER,
                 image TEXT,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # 创建分类表
    c.execute('''CREATE TABLE IF NOT EXISTS categories
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 name TEXT UNIQUE NOT NULL)''')

    # 创建订单表
    c.execute('''CREATE TABLE IF NOT EXISTS orders
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 user_id INTEGER NOT NULL,
                 total_price REAL NOT NULL,
                 status TEXT DEFAULT 'pending',
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # 创建订单项表
    c.execute('''CREATE TABLE IF NOT EXISTS order_items
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 order_id INTEGER NOT NULL,
                 product_id INTEGER NOT NULL,
                 quantity INTEGER NOT NULL,
                 price REAL NOT NULL)''')

    # 创建评论表
    c.execute('''CREATE TABLE IF NOT EXISTS comments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 product_id INTEGER NOT NULL,
                 user_id INTEGER NOT NULL,
                 content TEXT NOT NULL,
                 rating INTEGER NOT NULL,
                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')

    # 插入示例数据
    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        categories = [('电子产品',), ('服装',), ('食品',), ('图书',)]
        c.executemany("INSERT INTO categories (name) VALUES (?)", categories)

        products = [
            ('iPhone 13', '最新款苹果手机', 6999.00, 100, 1, 'iphone.jpg'),
            ('MacBook Pro', '苹果笔记本电脑', 12999.00, 50, 1, 'macbook.jpg'),
            ('牛仔裤', '经典蓝色牛仔裤', 299.00, 200, 2, 'jeans.jpg'),
            ('巧克力', '比利时进口巧克力', 99.00, 300, 3, 'chocolate.jpg'),
            ('Python编程', 'Python编程入门', 59.00, 150, 4, 'python_book.jpg')
        ]
        c.executemany(
            "INSERT INTO products (name, description, price, stock, category_id, image) VALUES (?, ?, ?, ?, ?, ?)",
            products)

    conn.commit()
    conn.close()


init_db()


# API路由
@app.route('/api/products', methods=['GET'])
def get_products():
    conn = sqlite3.connect('shop.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    category_id = request.args.get('category_id')
    if category_id:
        c.execute("SELECT * FROM products WHERE category_id = ?", (category_id,))
    else:
        c.execute("SELECT * FROM products")

    products = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify(products)


@app.route('/api/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    conn = sqlite3.connect('shop.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM products WHERE id = ?", (product_id,))
    product = c.fetchone()
    conn.close()

    if product:
        return jsonify(dict(product))
    return jsonify({"error": "Product not found"}), 404


@app.route('/api/categories', methods=['GET'])
def get_categories():
    conn = sqlite3.connect('shop.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute("SELECT * FROM categories")
    categories = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify(categories)


@app.route('/api/orders', methods=['POST'])
def create_order():
    data = request.json
    user_id = data.get('user_id')
    items = data.get('items')

    if not user_id or not items:
        return jsonify({"error": "Missing user_id or items"}), 400

    conn = sqlite3.connect('shop.db')
    c = conn.cursor()

    # 计算总价并检查库存
    total_price = 0
    for item in items:
        product_id = item['product_id']
        quantity = item['quantity']
        c.execute("SELECT price, stock FROM products WHERE id = ?", (product_id,))
        product = c.fetchone()
        if not product:
            conn.close()
            return jsonify({"error": f"Product {product_id} not found"}), 404
        if product[1] < quantity:
            conn.close()
            return jsonify({"error": f"Insufficient stock for product {product_id}"}), 400
        total_price += product[0] * quantity

    # 创建订单
    c.execute("INSERT INTO orders (user_id, total_price) VALUES (?, ?)",
              (user_id, total_price))
    order_id = c.lastrowid

    # 创建订单项并更新库存
    for item in items:
        product_id = item['product_id']
        quantity = item['quantity']
        c.execute("SELECT price FROM products WHERE id = ?", (product_id,))
        price = c.fetchone()[0]
        c.execute("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)",
                  (order_id, product_id, quantity, price))
        c.execute("UPDATE products SET stock = stock - ? WHERE id = ?", (quantity, product_id))

    conn.commit()
    conn.close()
    return jsonify({"order_id": order_id, "total_price": total_price}), 201


# 前端Vue应用
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python+Vue 网上商城</title>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios@0.21.1/dist/axios.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --success: #4cc9f0;
            --light: #f8f9fa;
            --dark: #212529;
        }
        body {
            background-color: #f5f7fb;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar {
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .product-card {
            transition: transform 0.3s, box-shadow 0.3s;
            border-radius: 10px;
            overflow: hidden;
            border: none;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .product-img {
            height: 200px;
            object-fit: cover;
        }
        .category-list .list-group-item {
            cursor: pointer;
            transition: all 0.2s;
        }
        .category-list .list-group-item:hover, 
        .category-list .list-group-item.active {
            background-color: var(--primary);
            color: white;
        }
        .btn-primary {
            background-color: var(--primary);
            border-color: var(--primary);
        }
        .btn-primary:hover {
            background-color: var(--secondary);
            border-color: var(--secondary);
        }
        .cart-icon {
            position: relative;
        }
        .cart-badge {
            position: absolute;
            top: -5px;
            right: -10px;
            background-color: var(--success);
            color: var(--dark);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .product-detail-img {
            max-height: 400px;
            object-fit: contain;
        }
        .rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .footer {
            background-color: var(--dark);
            color: var(--light);
            padding: 2rem 0;
            margin-top: 3rem;
        }
    </style>
</head>
<body>
    <div id="app">
        <!-- 导航栏 -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
            <div class="container">
                <a class="navbar-brand" href="#" @click="currentView='home'">Python商城</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="#" @click="currentView='home'">首页</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" @click="currentView='products'">全部商品</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" @click="currentView='user'">用户中心</a>
                        </li>
                    </ul>
                    <div class="d-flex">
                        <div class="input-group me-2">
                            <input type="text" class="form-control" placeholder="搜索商品" v-model="searchQuery">
                            <button class="btn btn-outline-light" @click="searchProducts">搜索</button>
                        </div>
                        <div class="cart-icon btn btn-light position-relative me-2" @click="currentView='cart'">
                            <i class="bi bi-cart"></i>
                            <span class="cart-badge" v-if="cart.length > 0">{{ cart.length }}</span>
                        </div>
                        <button class="btn btn-outline-light" v-if="!user" @click="showLoginModal=true">登录</button>
                        <div class="dropdown" v-else>
                            <button class="btn btn-outline-light dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown">
                                {{ user.username }}
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#" @click="currentView='orders'">我的订单</a></li>
                                <li><a class="dropdown-item" href="#" @click="logout">退出</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

        <!-- 主要内容区域 -->
        <div class="container mt-4">
            <!-- 首页 -->
            <div v-if="currentView === 'home'">
                <div class="jumbotron bg-primary text-white p-5 rounded mb-4">
                    <h1 class="display-4">欢迎来到Python商城</h1>
                    <p class="lead">精选全球好货，品质生活从这里开始</p>
                    <hr class="my-4">
                    <p>我们提供电子产品、服装、食品、图书等各类优质商品</p>
                    <button class="btn btn-light btn-lg" @click="currentView='products'">立即购物</button>
                </div>

                <h2 class="mb-4">热门商品</h2>
                <div class="row">
                    <div class="col-md-3 mb-4" v-for="product in featuredProducts" :key="product.id">
                        <div class="card product-card h-100">
                            <img :src="'https://picsum.photos/300/200?random=' + product.id" class="card-img-top product-img">
                            <div class="card-body">
                                <h5 class="card-title">{{ product.name }}</h5>
                                <p class="card-text text-success">¥{{ product.price.toFixed(2) }}</p>
                                <button class="btn btn-primary btn-sm" @click="addToCart(product)">加入购物车</button>
                                <button class="btn btn-outline-secondary btn-sm ms-2" @click="viewProductDetail(product)">详情</button>
                            </div>
                        </div>
                    </div>
                </div>

                <h2 class="mb-4">商品分类</h2>
                <div class="row">
                    <div class="col-md-3 mb-4" v-for="category in categories" :key="category.id">
                        <div class="card text-center">
                            <div class="card-body">
                                <h5 class="card-title">{{ category.name }}</h5>
                                <button class="btn btn-outline-primary" @click="viewCategory(category.id)">浏览商品</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 商品列表 -->
            <div v-if="currentView === 'products'">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">商品分类</div>
                            <div class="list-group category-list">
                                <a href="#" class="list-group-item list-group-item-action" 
                                   :class="{active: selectedCategory === null}"
                                   @click="selectedCategory = null">全部商品</a>
                                <a href="#" class="list-group-item list-group-item-action" 
                                   v-for="category in categories" 
                                   :key="category.id"
                                   :class="{active: selectedCategory === category.id}"
                                   @click="selectedCategory = category.id">
                                    {{ category.name }}
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <h2 class="mb-4">商品列表</h2>
                        <div class="row">
                            <div class="col-md-4 mb-4" v-for="product in filteredProducts" :key="product.id">
                                <div class="card product-card h-100">
                                    <img :src="'https://picsum.photos/300/200?random=' + product.id" class="card-img-top product-img">
                                    <div class="card-body">
                                        <h5 class="card-title">{{ product.name }}</h5>
                                        <p class="card-text text-success">¥{{ product.price.toFixed(2) }}</p>
                                        <p class="card-text text-muted small">{{ product.description.substring(0, 50) }}...</p>
                                        <button class="btn btn-primary btn-sm" @click="addToCart(product)">加入购物车</button>
                                        <button class="btn btn-outline-secondary btn-sm ms-2" @click="viewProductDetail(product)">详情</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 商品详情 -->
            <div v-if="currentView === 'product-detail' && currentProduct">
                <div class="row">
                    <div class="col-md-6">
                        <img :src="'https://picsum.photos/600/400?random=' + currentProduct.id" class="img-fluid product-detail-img">
                    </div>
                    <div class="col-md-6">
                        <h2>{{ currentProduct.name }}</h2>
                        <div class="rating mb-3">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-half"></i>
                            <span class="text-muted ms-2">(128条评价)</span>
                        </div>
                        <h3 class="text-danger mb-4">¥{{ currentProduct.price.toFixed(2) }}</h3>
                        <p class="mb-4">{{ currentProduct.description }}</p>
                        <div class="d-flex align-items-center mb-4">
                            <label class="me-2">数量:</label>
                            <input type="number" class="form-control w-25 me-3" min="1" :max="currentProduct.stock" v-model="quantity">
                            <button class="btn btn-primary me-2" @click="addToCart(currentProduct, quantity)">加入购物车</button>
                            <button class="btn btn-danger" @click="buyNow(currentProduct, quantity)">立即购买</button>
                        </div>
                        <div class="card">
                            <div class="card-header">商品信息</div>
                            <ul class="list-group list-group-flush">
                                <li class="list-group-item">库存: {{ currentProduct.stock }}件</li>
                                <li class="list-group-item">分类: {{ getCategoryName(currentProduct.category_id) }}</li>
                                <li class="list-group-item">上架时间: {{ formatDate(currentProduct.created_at) }}</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="mt-5">
                    <h3>商品评价</h3>
                    <div class="card mb-3" v-for="comment in comments" :key="comment.id">
                        <div class="card-body">
                            <h5 class="card-title">{{ comment.username }}</h5>
                            <div class="rating mb-2">
                                <i v-for="i in 5" :key="i" class="bi" :class="i <= comment.rating ? 'bi-star-fill' : 'bi-star'"></i>
                            </div>
                            <p class="card-text">{{ comment.content }}</p>
                            <small class="text-muted">{{ formatDate(comment.created_at) }}</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 购物车 -->
            <div v-if="currentView === 'cart'">
                <h2 class="mb-4">购物车</h2>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="table-light">
                            <tr>
                                <th>商品</th>
                                <th>单价</th>
                                <th>数量</th>
                                <th>小计</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(item, index) in cart" :key="index">
                                <td>
                                    <div class="d-flex align-items-center">
                                        <img :src="'https://picsum.photos/80/60?random=' + item.product.id" class="me-3" style="width: 80px;">
                                        <div>
                                            <h6 class="mb-0">{{ item.product.name }}</h6>
                                            <small class="text-muted">{{ item.product.description.substring(0, 30) }}...</small>
                                        </div>
                                    </div>
                                </td>
                                <td>¥{{ item.product.price.toFixed(2) }}</td>
                                <td>
                                    <div class="d-flex">
                                        <button class="btn btn-sm btn-outline-secondary" @click="updateQuantity(index, item.quantity - 1)">-</button>
                                        <input type="number" class="form-control form-control-sm mx-1" style="width: 60px;" v-model="item.quantity" min="1">
                                        <button class="btn btn-sm btn-outline-secondary" @click="updateQuantity(index, item.quantity + 1)">+</button>
                                    </div>
                                </td>
                                <td>¥{{ (item.product.price * item.quantity).toFixed(2) }}</td>
                                <td>
                                    <button class="btn btn-sm btn-danger" @click="removeFromCart(index)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr v-if="cart.length === 0">
                                <td colspan="5" class="text-center py-5">
                                    <h4 class="text-muted">购物车是空的</h4>
                                    <button class="btn btn-primary mt-3" @click="currentView='products'">去购物</button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="row mt-4" v-if="cart.length > 0">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">优惠券</h5>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="输入优惠码">
                                    <button class="btn btn-primary">应用</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">订单摘要</h5>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>商品总价:</span>
                                    <span>¥{{ cartTotal.toFixed(2) }}</span>
                                </div>
                                <div class="d-flex justify-content-between mb-2">
                                    <span>运费:</span>
                                    <span>¥{{ shippingFee.toFixed(2) }}</span>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <span>优惠:</span>
                                    <span class="text-success">-¥0.00</span>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between fw-bold">
                                    <span>总计:</span>
                                    <span>¥{{ (cartTotal + shippingFee).toFixed(2) }}</span>
                                </div>
                                <button class="btn btn-primary w-100 mt-3" @click="checkout">结算</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 用户中心 -->
            <div v-if="currentView === 'user'">
                <h2 class="mb-4">用户中心</h2>
                <div class="row">
                    <div class="col-md-3">
                        <div class="list-group">
                            <a href="#" class="list-group-item list-group-item-action" 
                               :class="{active: userTab === 'profile'}"
                               @click="userTab = 'profile'">个人资料</a>
                            <a href="#" class="list-group-item list-group-item-action" 
                               :class="{active: userTab === 'orders'}"
                               @click="userTab = 'orders'">我的订单</a>
                            <a href="#" class="list-group-item list-group-item-action" 
                               :class="{active: userTab === 'address'}"
                               @click="userTab = 'address'">收货地址</a 下面是一个基于 Python Flask 框架 + Vue.js 的简单网上商城系统实现方案。这个示例包含核心功能模块和代码结构，可根据需求进一步扩展。

### 后端 (Python Flask)

```python
# app.py - 主入口文件
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # 允许跨域请求
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///shop.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# 数据模型
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120))
    is_admin = db.Column(db.Boolean, default=False)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    tags = db.relationship('Tag', secondary='product_tag')

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True)

class Tag(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), unique=True)

product_tag = db.Table('product_tag',
    db.Column('product_id', db.Integer, db.ForeignKey('product.id')),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'))
)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    total_amount = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')  # pending/completed/cancelled
    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())

# 前台API
@app.route('/api/products', methods=['GET'])
def get_products():
    products = Product.query.all()
    return jsonify([{
        'id': p.id,
        'name': p.name,
        'price': p.price,
        'description': p.description[:100] + '...' if p.description else ''
    } for p in products])

@app.route('/api/products/<int:id>', methods=['GET'])
def get_product(id):
    product = Product.query.get_or_404(id)
    return jsonify(product.to_dict())

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    # 添加验证逻辑...
    new_user = User(username=data['username'], password=data['password'])
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User created'}), 201

# 后台管理API
@app.route('/admin/products', methods=['POST'])
def create_product():
    if not validate_admin(): return unauthorized()

    data = request.json
    new_product = Product(
        name=data['name'],
        price=data['price'],
        description=data.get('description', ''),
        stock=data.get('stock', 0)
    )
    db.session.add(new_product)
    db.session.commit()
    return jsonify({'id': new_product.id}), 201

@app.route('/admin/products/<int:id>', methods=['PUT'])
def update_product(id):
    if not validate_admin(): return unauthorized()

    product = Product.query.get_or_404(id)
    data = request.json
    product.name = data['name']
    product.price = data['price']
    # ...更新其他字段
    db.session.commit()
    return jsonify({'message': 'Updated'})

# 辅助函数
def validate_admin():
    # 实际实现中应使用JWT验证
    return request.headers.get('X-Admin-Token') == 'SECRET_ADMIN_TOKEN'

def unauthorized():
    return jsonify({'error': 'Unauthorized'}), 401

if __name__ == '__main__':
    app.run(debug=True)
```

### 前端 (Vue.js) 示例组件

```vue
<!-- 前台首页 components/Home.vue -->
<template>
  <div class="home">
    <h1>欢迎来到网上商城</h1>
    <div class="products">
      <div v-for="product in products" :key="product.id" class="product-card">
        <router-link :to="`/product/${product.id}`">
          <h3>{{ product.name }}</h3>
          <p>¥{{ product.price }}</p>
        </router-link>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      products: []
    }
  },
  async created() {
    const res = await fetch('/api/products')
    this.products = await res.json()
  }
}
</script>
```

```vue
<!-- 后台商品管理 AdminProducts.vue -->
<template>
  <div class="admin-products">
    <h1>商品管理</h1>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>名称</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="p in products" :key="p.id">
          <td>{{ p.id }}</td>
          <td>{{ p.name }}</td>
          <td>{{ p.price }}</td>
          <td>
            <button @click="editProduct(p)">编辑</button>
            <button @click="deleteProduct(p.id)">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 商品编辑表单 -->
    <div v-if="editingProduct">
      <h2>{{ editingProduct.id ? '编辑' : '添加' }}商品</h2>
      <input v-model="editingProduct.name" placeholder="商品名称">
      <input v-model="editingProduct.price" type="number" placeholder="价格">
      <button @click="saveProduct">保存</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      products: [],
      editingProduct: null
    }
  },
  methods: {
    async fetchProducts() {
      const res = await fetch('/admin/products', {
        headers: { 'X-Admin-Token': 'SECRET_AD