# 菜单字典：存储菜品名称及单价
menu = {
    "鱼香肉丝": 28,
    "宫保鸡丁": 32,
    "水煮鱼": 45,
    "麻婆豆腐": 26,
    "回锅肉": 35,
    "清炒时蔬": 22,
    "番茄鸡蛋汤": 18
}

# 订单字典：存储点菜名称及数量
order_list = {}


def order_dishes():
    """用户点菜功能"""
    print("\n=== 菜单 ===")
    for dish, price in menu.items():
        print(f"{dish}: {price}元")

    while True:
        dish = input("\n请输入菜品名称 (输入0结束点菜): ").strip()
        if dish == "0":
            break
        if dish not in menu:
            print("该菜品不存在，请重新输入！")
            continue

        try:
            quantity = int(input("请输入数量: "))
            if quantity <= 0:
                print("数量必须大于0！")
                continue
        except ValueError:
            print("请输入有效的数字！")
            continue

        # 更新订单
        if dish in order_list:
            order_list[dish] += quantity
        else:
            order_list[dish] = quantity
        print(f"已添加 {dish} x {quantity}")


def back_dishes():
    """用户退菜功能"""
    if not order_list:
        print("当前没有点菜记录！")
        return

    print("\n=== 当前订单 ===")
    for dish, quantity in order_list.items():
        print(f"{dish}: {quantity}份")

    while True:
        dish = input("\n请输入要退的菜品名称 (输入0结束退菜): ").strip()
        if dish == "0":
            break
        if dish not in order_list:
            print("该菜品不在订单中，请重新输入！")
            continue

        try:
            quantity = int(input("请输入要退的数量: "))
            if quantity <= 0:
                print("数量必须大于0！")
                continue
        except ValueError:
            print("请输入有效的数字！")
            continue

        # 更新订单
        if quantity >= order_list[dish]:
            del order_list[dish]
            print(f"已移除 {dish}")
        else:
            order_list[dish] -= quantity
            print(f"已减少 {dish} x {quantity}")

        if not order_list:
            print("订单已清空")
            break


def sum_dishes():
    """结账功能"""
    if not order_list:
        print("没有需要结账的菜品！")
        return

    print("\n=== 账单详情 ===")
    total = 0
    for dish, quantity in order_list.items():
        price = menu[dish]
        subtotal = price * quantity
        total += subtotal
        print(f"{dish}: {price}元 x {quantity} = {subtotal}元")

    print(f"\n总计: {total}元")

    # 应用折扣
    while True:
        try:
            discount = float(input("\n请输入折扣率 (0.1-1.0): "))
            if discount < 0.1 or discount > 1.0:
                print("折扣率必须在0.1到1.0之间！")
                continue
            break
        except ValueError:
            print("请输入有效的数字！")

    final_amount = total * discount
    print(f"\n折扣后金额: {final_amount:.2f}元")
    print("感谢惠顾，欢迎下次光临！")


# 主程序
def main():
    while True:
        print("\n===== 饭店点餐系统 =====")
        print("1. 点菜")
        print("2. 退菜")
        print("3. 结账")
        print("4. 退出系统")

        choice = input("请选择操作: ").strip()

        if choice == "1":
            order_dishes()
        elif choice == "2":
            back_dishes()
        elif choice == "3":
            sum_dishes()
            break
        elif choice == "4":
            print("已退出系统")
            break
        else:
            print("无效选择，请重新输入！")


if __name__ == "__main__":
    main()